function avg_distance = compute_avg_euclidean_distance(targets, trajectory)
    % COMPUTE_AVG_EUCLIDEAN_DISTANCE 计算 targets 和 trajectory 数据之间的平均欧式距离偏差
    %
    % 输入参数：
    %   targets: 一个 cell 数组，每个元素是一个 1×3 的矩阵，表示目标的 xyz 坐标
    %   trajectory: 一个 cell 数组，每个元素是一个 1×3 的矩阵，表示轨迹的 xyz 坐标
    %
    % 输出参数：
    %   avg_distance: targets 和 trajectory 之间的平均欧式距离偏差

    % 检查输入是否为 cell 数组
    if ~iscell(targets) || ~iscell(trajectory)
        error('输入必须是一个 cell 数组。');
    end

    % 检查 targets 和 trajectory 的长度是否一致
    if length(targets) ~= length(trajectory)
        error('targets 和 trajectory 的长度必须一致。');
    end

    % 初始化存储距离的数组
    distances = [];

    % 遍历 targets 和 trajectory
    for i = 1:length(targets)
        % 如果当前 targets 和 trajectory 都非空
        if ~isempty(targets{i}) && ~isempty(trajectory{i})
            % 计算欧式距离
            distance = norm(targets{i} - trajectory{i});
            % 将距离添加到数组中
            distances = [distances; distance];
        end
    end

    % 如果没有有效的点对，返回空
    if isempty(distances)
        avg_distance = [];
        warning('没有有效的点对可以计算欧式距离。');
        return;
    end

    % 计算平均欧式距离
    avg_distance = mean(distances);
end