function [speeds] = estimate_speed(trajectory, time_interval)
    % ESTIMATE_SPEED 估计物体移动的速度
    %
    % 输入参数：
    %   trajectory: 一个 cell 数组，每个元素是一个 3×1 的列向量，表示轨迹点
    %   time_interval: 两个数据点之间的时间间隔（单位：秒），默认值为 0.055 秒（55ms）
    %
    % 输出参数：
    %   speeds: 一个数组，表示每个数据点对应的速度（单位：米/秒）
    %
    % 示例调用：
    %   trajectory = {[], [1; 2; 3], [], [4; 5; 6], []};
    %   speeds = estimate_speed(trajectory); % 使用默认时间间隔 55ms
    %   speeds = estimate_speed(trajectory, 0.1); % 自定义时间间隔 100ms

    % 设置默认时间间隔为 55ms（0.055 秒）
    if nargin < 2
        time_interval = 0.055; % 默认时间间隔
    end

    % 初始化输出
    speeds = zeros(length(trajectory), 1); % 速度数组，初始值为 0

    % 找到第一个非空数据点的索引
    first_non_empty_index = find(~cellfun(@isempty, trajectory), 1);

    % 如果没有非空数据点，直接返回全零速度
    if isempty(first_non_empty_index)
        return;
    end

    % 从第一个非空数据点开始计算速度
    prev_non_empty_point = trajectory{first_non_empty_index}; % 上一个非空数据点
    prev_non_empty_index = first_non_empty_index; % 上一个非空数据点的索引

    for i = (first_non_empty_index + 1):length(trajectory)
        current_point = trajectory{i}; % 当前数据点

        % 如果当前数据点非空
        if ~isempty(current_point)
            % 计算与上一个非空数据点之间的距离
            distance = norm(current_point - prev_non_empty_point);

            % 计算时间间隔
            time = (i - prev_non_empty_index) * time_interval;

            % 计算速度
            speed = distance / time;

            % 填充当前数据点和上一个非空数据点之间的速度
            speeds(prev_non_empty_index:i) = speed;

            % 更新上一个非空数据点和索引
            prev_non_empty_point = current_point;
            prev_non_empty_index = i;
        end
    end

    % 第一个非空数据点之前的速度设置为 0
    speeds(1:(first_non_empty_index - 1)) = 0;
    speeds=speeds';
end