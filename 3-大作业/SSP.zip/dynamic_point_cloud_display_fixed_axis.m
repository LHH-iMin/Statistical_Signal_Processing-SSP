function dynamic_point_cloud_display_fixed_axis(targets, trajectory,filtered_point_clouds, noise_point_clouds, speeds, frames, pause_time)
    % DYNAMIC_POINT_CLOUD_DISPLAY_FIXED_AXIS 动态显示 targets、trajectory、filtered_point_clouds 和 noise_point_clouds 的点云，并固定坐标轴范围
    %
    % 输入参数：
    %   targets: 一个 cell 数组，每个元素是一个 n×3 的矩阵，表示目标点云数据
    %   trajectory: 一个 cell 数组，每个元素是一个 n×3 的矩阵，表示轨迹点云数据
    %   speeds: 一个数组（数值或 cell），表示每个数据点对应的速度
    %   frames: 一个数组（数值或 cell），表示帧索引
    %   pause_time: 每帧显示的时间间隔（秒）
    %   filtered_point_clouds: 一个 cell 数组，每个元素是一个 n×3 的矩阵，表示过滤后的点云数据
    %   noise_point_clouds: 一个 cell 数组，每个元素是一个 n×3 的矩阵，表示噪声点云数据


    % 检查输入参数
    if nargin < 5
        pause_time = 55*10^(-30)*1/20; % 默认暂停时间
    end

    % 如果 speeds 或 frames 是 cell 数组，转换为数值数组
    if iscell(speeds)
        speeds = cell2mat(speeds);
    end
    if iscell(frames)
        frames = cell2mat(frames);
    end

    % 找到 targets、trajectory中第一个非空数据的索引
    first_non_empty_target = find(~cellfun(@isempty, targets), 1);
    first_non_empty_trajectory = find(~cellfun(@isempty, trajectory), 1);

    % 确定起始帧（选择最小的索引）
    start_frame = min([first_non_empty_target, first_non_empty_trajectory]);

    % 计算所有点云的全局坐标范围（包括 targets、trajectory、filtered_point_clouds 和 noise_point_clouds）
    all_x = [];
    all_y = [];
    all_z = [];
    for i = 1:length(targets)
        current_target = targets{i};
        if ~isempty(current_target)
            all_x = [all_x; current_target(:, 1)]; % 收集 targets 的 x 值
            all_y = [all_y; current_target(:, 2)]; % 收集 targets 的 y 值
            all_z = [all_z; current_target(:, 3)]; % 收集 targets 的 z 值
        end
    end
    for i = 1:length(trajectory)
        current_trajectory = trajectory{i};
        if ~isempty(current_trajectory)
            all_x = [all_x; current_trajectory(:, 1)]; % 收集 trajectory 的 x 值
            all_y = [all_y; current_trajectory(:, 2)]; % 收集 trajectory 的 y 值
            all_z = [all_z; current_trajectory(:, 3)]; % 收集 trajectory 的 z 值
        end
    end
    for i = 1:length(filtered_point_clouds)
        current_filtered = filtered_point_clouds{i};
        if ~isempty(current_filtered)
            all_x = [all_x; current_filtered(:, 1)]; % 收集 filtered_point_clouds 的 x 值
            all_y = [all_y; current_filtered(:, 2)]; % 收集 filtered_point_clouds 的 y 值
            all_z = [all_z; current_filtered(:, 3)]; % 收集 filtered_point_clouds 的 z 值
        end
    end
    for i = 1:length(noise_point_clouds)
        current_noise = noise_point_clouds{i};
        if ~isempty(current_noise)
            all_x = [all_x; current_noise(:, 1)]; % 收集 noise_point_clouds 的 x 值
            all_y = [all_y; current_noise(:, 2)]; % 收集 noise_point_clouds 的 y 值
            all_z = [all_z; current_noise(:, 3)]; % 收集 noise_point_clouds 的 z 值
        end
    end

    % 计算全局最小值和最大值
    x_min = min(all_x);
    x_max = max(all_x);
    y_min = min(all_y);
    y_max = max(all_y);
    z_min = min(all_z);
    z_max = max(all_z);

    % 设置图形窗口
    figure;
    hold on;
    grid on;
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    view(3); % 设置 3D 视图

    % 固定坐标轴范围
    xlim([x_min, x_max]); % 设置 X 轴范围
    ylim([y_min, y_max]); % 设置 Y 轴范围
    zlim([z_min, z_max]); % 设置 Z 轴范围

    % 确定最大帧数
    max_frames = max([length(targets), length(trajectory), length(filtered_point_clouds), length(noise_point_clouds)]);

    % 动态显示每一帧（从起始帧开始）
    for i = start_frame:max_frames
        % 清空当前图形
        clf;
        hold on;
        grid on;
        xlabel('X');
        ylabel('Y');
        zlabel('Z');
        view(3); % 保持 3D 视图

        % 重新固定坐标轴范围
        xlim([x_min, x_max]); % 设置 X 轴范围
        ylim([y_min, y_max]); % 设置 Y 轴范围
        zlim([z_min, z_max]); % 设置 Z 轴范围

        % 显示 targets 点云
        if i <= length(targets)
            target_pc = targets{i};
            if ~isempty(target_pc)
                scatter3(target_pc(:, 1), target_pc(:, 2), target_pc(:, 3), 'filled', 'r'); % 红色表示 targets
            end
        end

        % 显示 trajectory 点云
        if i <= length(trajectory)
            trajectory_pc = trajectory{i};
            if ~isempty(trajectory_pc)
                scatter3(trajectory_pc(:, 1), trajectory_pc(:, 2), trajectory_pc(:, 3), 'filled', 'g'); % 绿色表示 trajectory
            end
        end

        % 显示 filtered_point_clouds 点云
        if i <= length(filtered_point_clouds)
            filtered_pc = filtered_point_clouds{i};
            if ~isempty(filtered_pc)
                scatter3(filtered_pc(:, 1), filtered_pc(:, 2), filtered_pc(:, 3), 'filled', 'b'); % 蓝色表示 filtered_point_clouds
            end
        end

        % 显示 noise_point_clouds 点云
        if i <= length(noise_point_clouds)
            noise_pc = noise_point_clouds{i};
            if ~isempty(noise_pc)
                scatter3(noise_pc(:, 1), noise_pc(:, 2), noise_pc(:, 3), 'filled', 'k'); % 黑色表示 noise_point_clouds
            end
        end

        % 显示速度和帧数
        if i <= length(speeds)
            speed = speeds(i);
        else
            speed = NaN; % 如果 speeds 数据不足，显示 NaN
        end
        if i <= length(frames)
            frame = frames(i);
        else
            frame = NaN; % 如果 frames 数据不足，显示 NaN
        end
        text(x_min, y_max, z_max - 0.1 * (z_max - z_min), sprintf('Speed: %.2f m/s\nFrame: %d', speed, frame), ...
            'VerticalAlignment', 'top', 'HorizontalAlignment', 'left', 'Color', 'k', 'FontSize', 10);
        
        % 设置 title，显示颜色说明
        title('\color{red}● Targets \color{green}● Trajectory \color{blue}● Filtered \color{black}● Noise', ...
            'Interpreter', 'tex', 'FontSize', 12);
        % 暂停指定时间
        pause(pause_time);
    end
end