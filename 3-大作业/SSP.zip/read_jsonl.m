function [frames,point_clouds, targets] = read_jsonl(file_path)
%读取数据，并将point_clouds和targets按cell形式保存，每一帧的数据点按n*3维的矩阵形式保存
    fid = fopen(file_path, 'r');
    if fid == -1
        error('无法打开文件: %s', file_path);
    end
    frames={};
    point_clouds = {};
    targets = {};

    while ~feof(fid)%循环条件，确保未到达文件末尾。
        line = fgetl(fid);%读取一行数据
        if ~isempty(line)
            data = jsondecode(line);
            
             % 处理 frame 数据
            if isfield(data, 'frameNum') && ~isempty(data.frameNum) % 判断是否存在 and 是否非空
                frames{end + 1} = data.frameNum;
            else
                frames{end + 1} = [];
            end

            % 处理pointcloud数据
            if isfield(data, 'pointcloud') && ~isempty(data.pointcloud)%判断是否存在and是否非空
                point_cloud = data.pointcloud;
                if size(point_cloud, 1) ~= 3
                    error('Invalid pointCloud shape. Expected 3 rows, got %d', size(point_cloud, 1));
                end
                point_clouds{end + 1} = point_cloud';
            else
                point_clouds{end + 1} = [];
            end

            % 处理targets数据
            if isfield(data, 'targets') && ~isempty(data.targets)%判断是否存在and是否非空
                target = data.targets;
                targets{end + 1} = [target(2), target(3), target(4)];
            else
                targets{end + 1} = [];
            end
        end
    end

    fclose(fid);
end