function [cleaned_point_clouds] = clean_data(point_clouds, targets)
    % CLEAN_DATA 根据指定范围过滤点云数据，并保持输出维度一致
    %
    % 输入参数：
    %   point_clouds: 一个 cell 数组，每个元素是一个 n×3 的矩阵，表示点云数据
    %   targets: 一个 cell 数组，每个元素是一个 n×3 的矩阵，用于计算全局坐标范围
    %
    % 输出参数：
    %   cleaned_point_clouds: 过滤后的点云数据，维度与 point_clouds 一致
    %

    % 初始化输出
    cleaned_point_clouds = cell(size(point_clouds)); % 保持与 point_clouds 相同的维度

    % 计算 targets 所有点云的全局坐标范围
    all_x = [];
    all_y = [];
    all_z = [];
    for i = 1:length(targets)
        current_point_cloud = targets{i};
        if ~isempty(current_point_cloud)
            all_x = [all_x; current_point_cloud(:, 1)]; % 收集所有 x 值
            all_y = [all_y; current_point_cloud(:, 2)]; % 收集所有 y 值
            all_z = [all_z; current_point_cloud(:, 3)]; % 收集所有 z 值
        end
    end

    % 定义过滤范围
    x_range = [floor(min(all_x)), ceil(max(all_x))];
    y_range = [floor(min(all_y)), ceil(max(all_y))];
    z_range = [floor(min(all_z)), ceil(max(all_z))];

    % 遍历每一帧
    for i = 1:length(point_clouds)
        pc = point_clouds{i}; % 获取当前点云

        % 如果当前点云为空，直接保存为空
        if isempty(pc)
            cleaned_point_clouds{i} = [];
            continue;
        end

        % 过滤 x, y, z 范围
        valid_indices_x = (pc(:, 1) >= x_range(1)) & (pc(:, 1) <= x_range(2));
        valid_indices_y = (pc(:, 2) >= y_range(1)) & (pc(:, 2) <= y_range(2));
        valid_indices_z = (pc(:, 3) >= z_range(1)) & (pc(:, 3) <= z_range(2));

        % 取交集，确保所有条件都满足
        valid_indices = valid_indices_x & valid_indices_y & valid_indices_z;

        % 提取满足条件的点
        pc_filtered = pc(valid_indices, :);

        % 去除所有维度值都为 0 的点（可选）
        non_zero_indices = sum(pc_filtered, 2) ~= 0;
        pc_filtered = pc_filtered(non_zero_indices, :);

        % 保存过滤后的点云
        cleaned_point_clouds{i} = pc_filtered;
    end
end