% 2025年1月12日 李厚华 空天信息创新研究院 lihouhua24@mail.ucas.ac.cn
clear all; clc; close all;

% 文件路径
file_path = 'D:\CODES_MATLAB\SSP\SSP_data\data_2c.jsonl';

% 读取数据
[frames, point_clouds, targets] = read_jsonl(file_path);

% 剔除异常值
cleaned_point_clouds = clean_data(point_clouds, targets);

% 通过临近点数量判断是否为噪声点
[filtered_point_clouds, noise_point_clouds] = filter_noise(cleaned_point_clouds);

% 提取运动轨迹
trajectory = extract_trajectory(filtered_point_clouds);

% 计算真实轨迹与估计轨迹的欧氏距离偏差
avg_distance = compute_avg_euclidean_distance(targets, trajectory);
disp(['平均欧氏距离偏差: ', num2str(avg_distance), ' 米']);

% 估计运动速度
speeds_trajectory = estimate_speed(trajectory);
speeds_targets = estimate_speed(targets);

% 画图参数设置
pause_time = 55 * 10^(-3) * 1 / 20; % 显示速度相较于原始速度加快20倍（55ms * 1/20）

% 绘制3D和2D轨迹图
plot_all_points(targets, trajectory); % 3D轨迹图
plot_all_points_2d(targets, trajectory); % 2D轨迹图

% 动态轨迹图
dynamic_point_cloud_display_fixed_axis(targets, trajectory, filtered_point_clouds, ...
    noise_point_clouds, speeds_trajectory, frames, pause_time);

% 绘制速度图
plot_speeds(speeds_targets, speeds_trajectory); % 速度对比图