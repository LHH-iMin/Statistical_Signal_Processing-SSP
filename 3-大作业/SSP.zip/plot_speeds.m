function plot_speeds(speeds_targets, speeds_trajectory)
    % PLOT_SPEEDS 绘制多个目标的速度随时间变化的二维图
    %
    % 输入参数：
    %   speeds_targets: 一个 n×m 的矩阵，表示 m 个目标的速度数据，每列对应一个目标的速度
    %   speeds_trajectory: 一个 n×m 的矩阵，表示 m 个目标的轨迹速度数据，每列对应一个目标的速度
    %
    % 设置图形窗口
    figure;
    hold on;
    grid on;
    xlabel('帧');
    ylabel('速度(m/s)');
    plot(speeds_targets);
    plot(speeds_trajectory);

    % 添加图例
    legend("Targets","Trajectory");
end