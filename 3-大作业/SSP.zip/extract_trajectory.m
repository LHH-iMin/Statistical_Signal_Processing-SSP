function trajectory = extract_trajectory(filtered_point_clouds)
    % EXTRACT_TRAJECTORY 从过滤后的点云数据中提取轨迹
    % 对每一帧，提取其前后各 4 帧（共 9 帧）的非空点云数据，计算均值作为当前帧的平均位置
    %
    % 输入参数：
    %   filtered_point_clouds: 一个 cell 数组，每个元素是一个 n×3 的矩阵，表示过滤后的点云数据
    %
    % 输出参数：
    %   trajectory: 一个 cell 数组，每个元素是一个 3×1 的列向量，表示轨迹点

    % 初始化输出
    num_frames = length(filtered_point_clouds);
    trajectory = cell(num_frames, 1);
    n=9;
    % 遍历每一帧
    for i = 1:num_frames
        % 确定当前帧的前后 n 帧范围
        start_frame = max(1, i - n); % 防止超出左边界
        end_frame = min(num_frames, i + n); % 防止超出右边界

        % 提取当前帧及其前后 n 帧的点云数据
        group_point_clouds = filtered_point_clouds(start_frame:end_frame);

        % 提取当前组中所有非空点云
        non_empty_point_clouds = group_point_clouds(~cellfun(@isempty, group_point_clouds));

        % 如果当前组有非空点云，计算平均位置
        if ~isempty(non_empty_point_clouds)
            % 将所有点云数据合并
            all_points = vertcat(non_empty_point_clouds{:});
            % 计算平均位置
            mean_point = mean(all_points, 1); % 1×3 向量
            % 将平均位置保存到当前帧
            trajectory{i} = mean_point;
        else
            % 如果当前组所有点云都为空，保存空数组
            trajectory{i} = [];
        end
    end

    % 将 trajectory 转置为行向量形式
    trajectory = trajectory';
end