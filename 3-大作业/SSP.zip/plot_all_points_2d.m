function plot_all_points_2d(targets, trajectory)
    % PLOT_ALL_POINTS_2D 绘制 targets 和 trajectory 的所有数据点（平面图）
    %
    % 输入参数：
    %   targets: 一个 cell 数组，每个元素是一个 n×3 的矩阵，表示目标点云数据
    %   trajectory: 一个 cell 数组，每个元素是一个 n×3 的矩阵，表示轨迹点云数据
    %
    % 示例调用：
    %   targets = {[1, 2, 3; 4, 5, 6], [], [10, 11, 12; 13, 14, 15]};
    %   trajectory = {[1, 1, 1], [], [2, 2, 2], [10, 10, 10]};
    %   plot_all_points_2d(targets, trajectory);

    % 初始化 targets 和 trajectory 的所有点
    all_targets = [];
    all_trajectory = [];

    % 合并 targets 的所有点
    for i = 1:length(targets)
        current_target = targets{i};
        if ~isempty(current_target)
            all_targets = [all_targets; current_target(:, 1:2)]; % 只取 x 和 y 坐标
        end
    end

    % 合并 trajectory 的所有点
    for i = 1:length(trajectory)
        current_trajectory = trajectory{i};
        if ~isempty(current_trajectory)
            all_trajectory = [all_trajectory; current_trajectory(:, 1:2)]; % 只取 x 和 y 坐标
        end
    end

    % 如果没有数据，直接返回
    if isempty(all_targets) && isempty(all_trajectory)
        error('targets 和 trajectory 中没有任何数据！');
    end

    % 设置图形窗口
    figure;
    hold on;
    grid on;
    xlabel('X');
    ylabel('Y');
    axis equal; % 保持 x 和 y 轴比例一致

    % 绘制 targets 的所有点
    if ~isempty(all_targets)
        scatter(all_targets(:, 1), all_targets(:, 2),15, 'filled', 'r'); % 红色表示 targets
    end

    % 绘制 trajectory 的所有点
    if ~isempty(all_trajectory)
        scatter(all_trajectory(:, 1), all_trajectory(:, 2), 15,'filled', 'g'); % 绿色表示 trajectory
    end

    % 添加图例
    legend('Targets', 'Trajectory', 'Location', 'best');

    % 设置标题
    title(" Targets and Trajectory (2D)");
end