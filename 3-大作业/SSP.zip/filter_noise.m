function [filtered_point_clouds, noise_point_clouds] = filter_noise(point_clouds, threshold, radius, min_neighbors)
    % FILTER_NOISE 基于邻域密度的噪声剔除函数，保持输出维度一致
    %
    % 输入参数：
    %   point_clouds: 一个 cell 数组，每个元素是一个 n×3 的矩阵，表示点云数据
    %   threshold: 最小点数阈值。如果某一帧的点数少于 threshold，则跳过该帧
    %   radius: 邻域半径，用于判断点与点之间的距离
    %   min_neighbors: 最小邻居数，用于判断一个点是否有效
    %
    % 输出参数：
    %   filtered_point_clouds: 过滤后的点云数据，维度与 point_clouds 一致
    %   noise_point_clouds: 一个 cell 数组，保存每一帧中被滤除的噪声数据，如果没有噪声数据，则为空
    %

    % 参数检查与默认值设置
    if nargin < 4
        min_neighbors = 5; % 默认最小邻居数
    end
    if nargin < 3
        radius = 0.5; % 默认邻域半径
    end
    if nargin < 2
        threshold = 5; % 默认最小点数阈值
    end

    % 初始化输出
    filtered_point_clouds = cell(size(point_clouds)); % 保持与 point_clouds 相同的维度
    noise_point_clouds = cell(size(point_clouds)); % 保存每一帧的噪声数据

    % 遍历每一帧
    for i = 1:length(point_clouds)
        pc = point_clouds{i}; % 获取当前点云
        n = size(pc, 1); % 当前点云的点数

        % 如果当前点云点数少于阈值，保存为空
        if n < threshold
            filtered_point_clouds{i} = [];
            noise_point_clouds{i} = pc; % 没有噪声数据
            continue;
        end

        % 计算点与点之间的欧氏距离
        distances = pdist(pc); % 计算点与点之间的距离
        distances_matrix = squareform(distances); % 转换为距离矩阵

        % 统计每个点的邻域点数
        neighbor_counts = sum(distances_matrix <= radius & distances_matrix ~= 0, 2);

        % 提取有效点（邻域点数 >= min_neighbors）
        valid_indices = neighbor_counts >= min_neighbors;
        filtered_pc = pc(valid_indices, :); % 过滤后的点云
        noise_pc = pc(~valid_indices, :); % 被滤除的噪声数据

        % 保存过滤后的点云和噪声数据
        filtered_point_clouds{i} = filtered_pc;
        noise_point_clouds{i} = noise_pc;
    end
end